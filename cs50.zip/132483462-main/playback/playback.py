#Exercise3
#implement a program in Python that prompts the user for input and then outputs that same input, replacing each space with ... (i.e., three periods).
text = input("text: ")
result  = text.replace(" ", "...")
print(result)
