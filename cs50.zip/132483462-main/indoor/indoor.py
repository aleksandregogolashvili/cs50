#Exercise2
#implement a program in Python that prompts the user for input and then outputs that same input in lowercase
print(input("Please write your text: ").lower())