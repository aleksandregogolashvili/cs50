#Exercise 1
#ask user the name and let him write
name = input("What is your name? ").strip()
#print hello
print(f"Hello, {name}, Nice to meet you")

